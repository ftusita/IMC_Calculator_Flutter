import 'package:flutter/material.dart';
import 'package:flutter_calculadora_imc/pages/calculadora_page.dart';
import 'package:flutter_calculadora_imc/pages/constants.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
 @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData.dark().copyWith(
        primaryColor: backgroundColor,
        scaffoldBackgroundColor: backgroundColor,
        appBarTheme: const AppBarTheme().copyWith(
          backgroundColor: backgroundColor,
        ),
      ),
      home: const CalculadoraPage(),
    );
  }
}
class ListaPage extends StatelessWidget {
  ListaPage({super.key});

  final List<Contato> contatos = [
    Contato('Felipe', 'felipe@gmail.com'),
    Contato('Carlos', 'carlos@gmail.com'),
    Contato('Pedro', 'pedro@gmail.com'),
    Contato('Victor', 'victor@gmail.com'),
    Contato('Lucas', 'lucas@gmail.com'),
    Contato('Maria', 'maria@gmail.com'),
    Contato('Ana', 'ana@gmail.com'),
    Contato('Juliana', 'juliana@gmail.com'),
    Contato('Gustavo', 'gustavo@gmail.com'),
    Contato('Paula', 'paula@gmail.com'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ListView Builder Demo'),
      ),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (BuildContext context, int index) {
          String firstLetter = contatos[index].nome[0].toUpperCase();
          return ListTile(
            leading: CircleAvatar(
              child: Text(firstLetter),
            ),
            title: Text(contatos[index].nome),
            subtitle: Text(contatos[index].email),
          );
        },
      ),
    );
  }
}
class Contato {
  String nome;
  String email;
  Contato(this.nome, this.email);
}
